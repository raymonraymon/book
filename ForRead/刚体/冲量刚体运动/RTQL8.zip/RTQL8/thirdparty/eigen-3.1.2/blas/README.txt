
This directory contains a BLAS library built on top of Eigen.

This is currently a work in progress which is far to be ready for use,
but feel free to contribute to it if you wish.

This module is not built by default. In order to compile it, you need to
type 'make blas' from within your build dir.

