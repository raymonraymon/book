/* RTQL8, Copyright (c) 2011, Georgia Tech Research Corporation
 * All rights reserved.
 *
 * Author(s): Sumit Jain <sumitj83@gmail.com>, Sehoon Ha <sehoon.ha@gmail.com>
 * Georgia Tech Graphics Lab
 * 
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * This code incorporates portions of Open Dynamics Engine 
 *     (Copyright (c) 2001-2004, Russell L. Smith. All rights 
 *     reserved.) and portions of FCL (Copyright (c) 2011, Willow 
 *     Garage, Inc. All rights reserved.), which were released under
 *     the same BSD license as below
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef KINEMATICS_C3D_H
#define KINEMATICS_C3D_H

#include <vector>
#include <ctime>
#include <Eigen/Dense>
#include "utils/EigenHelper.h"

////////////////////////////////////////////////////////////////////////////////
//  C3D file reader and writer
namespace rtql8 {
    namespace kinematics {

    #define C3D_REC_SIZE   512

        typedef struct c3d_head_t {
            unsigned char	prec_start;
            unsigned char	key;
            short	pnt_cnt;
            short	a_channels;
            short	start_frame;
            short	end_frame;
            short	int_gap;
            float	scale;
            short	rec_start;
            short	a_frames;
            float	freq;
            short	stuff[244];
        } c3d_head;

        typedef struct c3d_param_t {
            unsigned char	reserved[2];
            unsigned char	pblocks;
            unsigned char	ftype;
            char stuff[C3D_REC_SIZE-4];
        } c3d_param;

        typedef struct c3d_frameSI_t {
            short	x, y, z;
            unsigned char	cam_byte;
            unsigned char	residual;
        } c3d_frameSI;

        typedef struct c3d_frame_t {
            float	x, y, z;
            float	residual;
        } c3d_frame;

        float convertDecToFloat(char _bytes[4]);
        void convertFloatToDec(float _f, char* _bytes);

        bool loadC3DFile( const char *_fileName, EIGEN_VV_VEC3D& _pointData,
                          int *_nFrame, int *_nMarker, double *_freq );
        bool saveC3DFile( const char* _fileName, EIGEN_VV_VEC3D& _pointData,
                          int _nFrame, int _nMarker, double _freq );

        double maxElem(std::vector<double>& _arr, int& _index);
        double minElem(std::vector<double>& _arr, int& _index);

    } // namespace kinematics
} // namespace rtql8

#endif // #ifndef KINEMATICS_C3D_H


