/* RTQL8, Copyright (c) 2011, Georgia Tech Research Corporation
 * All rights reserved.
 *
 * Author(s): Sehoon Ha <sehoon.ha@gmail.com>
 * Georgia Tech Graphics Lab
 * 
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * This code incorporates portions of Open Dynamics Engine 
 *     (Copyright (c) 2001-2004, Russell L. Smith. All rights 
 *     reserved.) and portions of FCL (Copyright (c) 2011, Willow 
 *     Garage, Inc. All rights reserved.), which were released under
 *     the same BSD license as below
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#include "ObjectiveBox.h"
#include "Constraint.h"
using namespace Eigen;
#include <iostream>
using namespace std;

namespace rtql8 {
    namespace optimizer {

        ObjectiveBox::ObjectiveBox(int numDofs) {
            setNumDofs(numDofs);
            mObj = 0.0;
        }

        ObjectiveBox::~ObjectiveBox() {
            clear();
        }

        void ObjectiveBox::add(Constraint *newObjective) {
            mObjectives.push_back(newObjective);
        }

        void ObjectiveBox::clear() {
            mObjectives.clear();
        }

        int ObjectiveBox::remove(Constraint *obj) {
            int index = -1;
            for(unsigned int i = 0; i < mObjectives.size(); i++){
                if(mObjectives[i] == obj){
                    index = i;
                    break;
                }
            }

            if(index == -1) {
                return index;
            }

            //deallocate memory for Constraint
            mObjectives.erase(mObjectives.begin() + index);

            return index;
        }

        int ObjectiveBox::isInBox(Constraint *testObj)  {
            for(unsigned int i = 0; i < mObjectives.size(); i++) {
                if(mObjectives[i] == testObj)
                    return i;
            }
            return -1;
        }

        void ObjectiveBox::setNumDofs(int numDofs) {

            mNumDofs = numDofs;
            mObj = 0;
            mObjGrad.resize(numDofs);

            for(int i = 0; i < numDofs; i++) {
                mObjGrad[i] = 0.0;
            }
        }

        void ObjectiveBox::evalObjGrad() {
            for (unsigned int i = 0; i < mObjGrad.size(); i++)
                mObjGrad[i] = 0.0;

            for (unsigned int i = 0; i < mObjectives.size(); i++) {
                if (mObjectives[i]->mActive){
                    mObjectives[i]->fillObjGrad(mObjGrad);
                }
            }
        }

        void ObjectiveBox::evalObjHess() {
        }

        void ObjectiveBox::evalObj() {
            mObj = 0;
            for(unsigned int i = 0; i < mObjectives.size(); i++)
                if(mObjectives[i]->mActive)
                    mObj += mObjectives[i]->evalObj();
        }

        void ObjectiveBox::reallocateMem() {
            for(unsigned int i = 0; i < mObjectives.size(); i++)
                mObjectives[i]->allocateMem();
        }


    } // namespace optimizer
} // namespace rtql8
